<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!-- Start Content Area -->
<section class="sample-text-area">
	<div class="container">
		<div class="">
			<img class="img-fluid col-lg-12" src="<?=base_url('asset/images/struktur.jpg') ?>">
		</div>
	</div>
</section>
<!-- End Content Area -->