<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!-- Start Content Area -->
<section class="sample-text-area">
	<div class="container">
		<div class="text-center">
			<h1>Jadwal Praktikum</h1>
			<h3 class="text-heading">Laboratorium Teknik Informatika</h3>
			<p class="section-title np">Terakhir update 30 September 2019</p>
			<p class="section-title">Berlaku mulai 7 Oktober 2019</p>
		</div>
		<div class="">
			<img class="img-fluid col-lg-12" src="<?=base_url('asset/images/E532.png') ?>">
			<img class="img-fluid col-lg-12 mt-3" src="<?=base_url('asset/images/H4045.png') ?>">
			<img class="img-fluid col-lg-12 mt-3" src="<?=base_url('asset/images/H406.png') ?>">
			<img class="img-fluid col-lg-12 mt-3" src="<?=base_url('asset/images/H407.png') ?>">
			<img class="img-fluid col-lg-12 mt-3" src="<?=base_url('asset/images/H408.png') ?>">
		</div>
	</div>
</section>
<!-- End Content Area -->